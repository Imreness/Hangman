HANGMAN - 2019
--------------------------------
A simple hangman game for practice purposes.
--------------------------------


HOW TO USE CUSTOM WORDS
--------------------------------
Open "customwordlist.txt" in the game's folder.
In there, you'll find instructions on how to use it.

Once you're done there, head into the game, and change
the wordset to custom in the options menu
--------------------------------


GAME DOESNT LAUNCH, MISSING .DLL FILES!
--------------------------------
In that case, open the redist folder included with the game.
Install both vc_redist.x64.exe and oalinst.exe. Both of them should be on your
computer by default, but if they're not, you can just install them.

Then the game should launch just fine!
--------------------------------


GAME CRASHED!
--------------------------------
Please leave a comment on the Itch.io page, about what you did prior to the crash...
And that the game sucks or something.
--------------------------------

Have fun!